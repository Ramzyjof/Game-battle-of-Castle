package com.example.gamebattleofcastle.model.castles;

import com.example.gamebattleofcastle.model.Castle;

public class Stone extends Castle {
  public Stone(String name) {
    super(name);
  }
}
