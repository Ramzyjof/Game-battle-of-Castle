package com.example.gamebattleofcastle.model.castles;

import com.example.gamebattleofcastle.model.Castle;

public class Horse extends Castle {
  public Horse(String name) {
    super(name);
  }
}
