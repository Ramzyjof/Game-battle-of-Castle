package com.example.gamebattleofcastle.model.castles;

import com.example.gamebattleofcastle.model.Castle;

public class Wood extends Castle {
  public Wood(String name) {
    super(name);
  }
}
