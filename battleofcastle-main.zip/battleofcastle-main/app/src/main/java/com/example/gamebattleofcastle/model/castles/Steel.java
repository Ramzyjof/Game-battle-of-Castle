package com.example.gamebattleofcastle.model.castles;

import com.example.gamebattleofcastle.model.Castle;

public class Steel extends Castle {
  public Steel(String name) {
    super(name);
  }
}
