package com.example.gamebattleofcastle;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gamebattleofcastle.model.Army;
import com.example.gamebattleofcastle.model.Castle;
import com.example.gamebattleofcastle.model.Hero;
import com.example.gamebattleofcastle.model.Player;
import com.example.gamebattleofcastle.model.armies.Archer;
import com.example.gamebattleofcastle.model.armies.Cavalry;
import com.example.gamebattleofcastle.model.armies.Infantry;
import com.example.gamebattleofcastle.model.castles.Horse;
import com.example.gamebattleofcastle.model.castles.Steel;
import com.example.gamebattleofcastle.model.heroes.HeroArcher;
import com.example.gamebattleofcastle.model.heroes.HeroCavalry;
import com.example.gamebattleofcastle.model.heroes.HeroInfantry;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
  private Button fightButton;
  private TextView textHeader;
  private ImageView imgPlayerA, imgPlayerB, playerAWin, playerBWin;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    fightButton = findViewById(R.id.button_fight);
    textHeader = findViewById(R.id.txt_war_header);
    imgPlayerA = findViewById(R.id.imgPlayerA);
    imgPlayerB = findViewById(R.id.imgPlayerB);
    playerAWin = findViewById(R.id.img_winner_a);
    playerBWin = findViewById(R.id.img_winner_b);

    initFirstBattle();
  }

  // init first battle
  private void initFirstBattle() {
    textHeader.setText("Cavalry vs Infantry");
    imgPlayerA.setImageResource(R.drawable.img_cavalry);
    imgPlayerB.setImageResource(R.drawable.img_infantry);

    Castle castleA = new Horse("Horse Castle");
    Castle castleB = new Steel("Steel Castle");
    ArrayList<Hero> heroesA = new ArrayList<>();
    ArrayList<Hero> heroesB = new ArrayList<>();
    ArrayList<Army> armiesA = new ArrayList<>();
    ArrayList<Army> armiesB = new ArrayList<>();

    for (int i = 0; i < 5; i++)
      heroesA.add(new HeroCavalry("Cavalry Lead " + i, 100));
    for (int i = 0; i < 100_000; i++)
      armiesA.add(new Cavalry("Cavalry " + i, 100, 100));

    for (int i = 0; i < 5; i++)
      heroesB.add(new HeroInfantry("Infantry Lead " + i, 100));
    for (int i = 0; i < 100_000; i++)
      armiesB.add(new Infantry("Infantry " + i, 100, 100));

    Player playerA = new Player("Player A", castleA, heroesA, armiesA);
    Player playerB = new Player("Player B", castleB, heroesB, armiesB);

    fightButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        firstBattle(playerA, playerB);
      }
    });
  }

  // start first battle
  private void firstBattle(Player playerA, Player playerB) {
    int troops_amount_a = playerA.getCavalryAmount();
    int troops_amount_b = playerB.getInfantryAmount();

    troops_amount_a -= 0.1 * playerB.getInfantryAmount();
    troops_amount_b -= 0.4 * playerA.getCavalryAmount();

    if (troops_amount_a > troops_amount_b)
      playerAWin.setVisibility(View.VISIBLE);
    else if (troops_amount_a < troops_amount_b)
      playerBWin.setVisibility(View.VISIBLE);

    fightButton.setText("NEXT BATTLE");
    fightButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        initSecondBattle();
      }
    });
  }

  // init second battle
  private void initSecondBattle() {
    playerAWin.setVisibility(View.INVISIBLE);
    playerBWin.setVisibility(View.INVISIBLE);
    textHeader.setText("Infantry vs (Cavalry + Range)");
    imgPlayerA.setImageResource(R.drawable.img_infantry);
    imgPlayerB.setImageResource(R.drawable.img_cavalry);

    Castle castleA = new Steel("Steel Castle");
    Castle castleB = new Horse("Horse Castle");
    ArrayList<Hero> heroesA = new ArrayList<>();
    ArrayList<Hero> heroesB = new ArrayList<>();
    ArrayList<Army> armiesA = new ArrayList<>();
    ArrayList<Army> armiesB = new ArrayList<>();

    for (int i = 0; i < 5; i++)
      heroesA.add(new HeroInfantry("Infantry Lead " + i, 100));
    for (int i = 0; i < 100_000; i++)
      armiesA.add(new Infantry("Infantry " + i, 100, 100));

    for (int i = 0; i < 3; i++)
      heroesB.add(new HeroCavalry("Cavalry Lead " + i, 100));
    for (int i = 0; i < 60_000; i++)
      armiesB.add(new Cavalry("Cavalry " + i, 100, 100));
    for (int i = 0; i < 2; i++)
      heroesB.add(new HeroArcher("Archer Lead " + i, 100));
    for (int i = 0; i < 40_000; i++)
      armiesB.add(new Archer("Archer " + i, 100, 100));

    Player playerA = new Player("Player A", castleA, heroesA, armiesA);
    Player playerB = new Player("Player B", castleB, heroesB, armiesB);

    fightButton.setText("FIGHT");
    fightButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        secondBattle(playerA, playerB);
      }
    });
  }

  // start second battle
  private void secondBattle(Player playerA, Player playerB) {
    int troops_amount_a = playerA.getInfantryAmount();
    int troops_amount_b_cavalry = playerB.getCavalryAmount();
    int troops_amount_b_archer = playerB.getArcherAmount();

    troops_amount_a -= 0.4 * playerB.getCavalryAmount();
    troops_amount_a -= 0.1 * playerB.getArcherAmount();
    troops_amount_b_cavalry -= 0.1 * playerA.getInfantryAmount();
    troops_amount_b_archer -= 0.4 * playerA.getInfantryAmount();

    if (troops_amount_a > troops_amount_b_cavalry + troops_amount_b_archer)
      playerAWin.setVisibility(View.VISIBLE);
    else if (troops_amount_a < troops_amount_b_cavalry + troops_amount_b_archer)
      playerBWin.setVisibility(View.VISIBLE);

    fightButton.setText("END BATTLE");
    fightButton.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        finish();
      }
    });
  }
}